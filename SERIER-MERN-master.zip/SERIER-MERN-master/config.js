export default {
    jwtSecret: 'somesecretkeyforjwt'
};